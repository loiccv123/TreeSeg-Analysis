@echo off
setlocal enabledelayedexpansion

REM ===== HOW TO RUN - WINDOWS =====
REM ===== cd C:\Users\Labo Messier\Downloads
REM ===== run_cloudcompare_blocks.bat =====

REM ===== SETTINGS =====
set CC="C:\Program Files\CloudCompare\CloudCompare.exe"
set INPUT_DIR=C:\Users\Labo Messier\Downloads\2026_blocs
set LOGFILE=%INPUT_DIR%\cloudcompare_batch_log.csv

REM ===== CREATE LOG HEADER =====
echo file,start_time,end_time,duration_seconds,points_before,points_after,status > "%LOGFILE%"

REM ===== LOOP THROUGH FILES =====
for %%F in ("%INPUT_DIR%\2026_bloc*.las") do (

    echo.
    echo ==========================================
    echo Processing %%~nxF
    echo ==========================================

    set START=%TIME%

    REM ---- Count points before ----
    for %%A in ("%%F") do set SIZE_BEFORE=%%~zA

    REM ---- Run CloudCompare ----
    %CC% ^
    -SILENT ^
    -AUTO_SAVE OFF ^
    -O "%%F" ^
    -CSF ^
    -SCENES FLAT ^
    -CLASS_THRESHOLD 0.045 ^
    -CLOTH_RESOLUTION 0.07 ^
    -MAX_ITERATION 500 ^
    -SELECT_ENTITIES ^
    -REGEX ".*offground.*" ^
    -C_EXPORT_FMT LAZ ^
    -NOISE RADIUS 0.07 REL 1.0 ^
    -SOR 10 1.0 ^
    -SAVE_CLOUDS

    set EXITCODE=!ERRORLEVEL!

    set END=%TIME%

    REM ---- Try finding produced LAZ ----
    set OUTPUT_FILE=

    for %%O in ("%INPUT_DIR%\*_SOR*.laz") do (
        set OUTPUT_FILE=%%O
    )

    if defined OUTPUT_FILE (
        for %%B in ("!OUTPUT_FILE!") do set SIZE_AFTER=%%~zB
    ) else (
        set SIZE_AFTER=0
    )

    REM ---- Success / failure ----
    if !EXITCODE! EQU 0 (
        set STATUS=SUCCESS
    ) else (
        set STATUS=FAILED
    )

    REM ---- Log line ----
    echo %%~nxF,!START!,!END!,N/A,!SIZE_BEFORE!,!SIZE_AFTER!,!STATUS! >> "%LOGFILE%"

)

echo.
echo Finished batch processing.
echo Log saved to:
echo %LOGFILE%

pause