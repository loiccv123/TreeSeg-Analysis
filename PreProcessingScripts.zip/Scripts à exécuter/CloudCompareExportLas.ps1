$CC = "C:\Program Files\CloudCompare\CloudCompare.exe"

$INPUT_FOLDER = "C:\Users\Labo Messier\Downloads\8_mai\Scans"
$OUTPUT_FOLDER = "C:\Users\Labo Messier\Downloads\8_mai"

if (-not (Test-Path $OUTPUT_FOLDER)) {
New-Item -ItemType Directory -Path $OUTPUT_FOLDER | Out-Null
}

$flsFiles = Get-ChildItem "$INPUT_FOLDER" -Filter "*.fls"

Write-Host "Found $($flsFiles.Count) .fls files"

foreach ($file in $flsFiles) {

Write-Host "`nProcessing: $($file.Name)"

Push-Location $OUTPUT_FOLDER

& $CC `
    -SILENT `
    -LOG_FILE "$OUTPUT_FOLDER\log.txt" `
    -NO_TIMESTAMP `
    -AUTO_SAVE OFF `
    -O "$($file.FullName)" `
    -C_EXPORT_FMT LAS `
    -SAVE_CLOUDS `
    -CLEAR

Pop-Location

Write-Host "Started processing: $($file.Name)" -ForegroundColor Green

}

Write-Host "`nAll processing in the background, wait until all files have been outputted before closing."
Read-Host "Press Enter to close"