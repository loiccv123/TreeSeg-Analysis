@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\Labo Messier\Downloads\Loic_py_scripts\CloudCompareExportLas.ps1"
pause