"""
metashape_export_selected_scans.py
Run inside Metashape Pro:
    Tools > Run Script

Exports each SELECTED laser scan as an individual LAS file.

The export respects the current chunk bounding region
(red clipping box / crop region) via clip_to_boundary=True.

No scanner positions are calculated or saved.
"""

import Metashape
import os

# ── CONFIGURATION ─────────────────────────────────────────────────────────────
OUTPUT_DIR = r"C:\Users\Labo Messier\Downloads\2026_bloc2"
# ─────────────────────────────────────────────────────────────────────────────


doc = Metashape.app.document
chunk = doc.chunk

if chunk is None:
    raise RuntimeError("No active chunk found. Open a project first.")

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Log file ──────────────────────────────────────────────────────────────────
log_path = os.path.join(OUTPUT_DIR, "export_log.txt")
log_file = open(log_path, "w", encoding="utf-8")


def log(msg=""):
    print(msg)
    log_file.write(msg + "\n")
    log_file.flush()


# ── Header ────────────────────────────────────────────────────────────────────
log("=" * 60)
log("metashape_export_selected_scans.py")
log("=" * 60)
log(f"Output dir: {OUTPUT_DIR}")
log("")

# ── Get selected point clouds ────────────────────────────────────────────────
selected_pcs = [pc for pc in chunk.point_clouds if pc.selected]

if not selected_pcs:
    log("ERROR: No scans selected.")
    log("Select one or more scans in the Workspace panel first.")
    log_file.close()
    raise RuntimeError("No scans selected.")

log(f"Selected scans: {len(selected_pcs)}")
log("")

# ── Export ────────────────────────────────────────────────────────────────────
exported = 0
skipped = 0

for pc in selected_pcs:

    label = pc.label or ""

    if not label:
        log(f"  SKIP — unnamed point cloud (key={pc.key})")
        skipped += 1
        continue

    # Filesystem-safe filename
    safe_name = (
        label
        .replace(" ", "_")
        .replace("/", "-")
        .replace("\\", "-")
    )

    out_path = os.path.join(OUTPUT_DIR, f"{safe_name}.las")

    try:

        chunk.exportPointCloud(
            path=out_path,
            format=Metashape.PointCloudFormatLAS,
            point_clouds=[pc],
            clip_to_boundary=True
        )

        exported += 1

        log(f"  [{exported:03d}] Exported: {safe_name}.las")

    except Exception as e:

        log(f"  ERROR exporting {safe_name}")
        log(f"  {e}")

# ── Summary ───────────────────────────────────────────────────────────────────
log("")
log("=" * 60)
log(f"  Exported : {exported}")
log(f"  Skipped  : {skipped}")
log(f"  Log file : {log_path}")
log("=" * 60)

log_file.close()