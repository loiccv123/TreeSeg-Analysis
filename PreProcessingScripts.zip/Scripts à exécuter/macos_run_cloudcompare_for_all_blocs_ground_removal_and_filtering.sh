#!/usr/bin/env bash
set -u

CC="/Applications/CloudCompare.app/Contents/MacOS/CloudCompare"
INPUT_DIR="/Users/Shared/UQAM/2026/2026_blocs"
LOG_FILE="$INPUT_DIR/cloudcompare_batch_log.csv"

mkdir -p "$INPUT_DIR"

if [[ ! -x "$CC" ]]; then
  echo "CloudCompare not found or not executable: $CC" >&2
  exit 1
fi

# CSV header (created once)
if [[ ! -f "$LOG_FILE" ]]; then
  echo "timestamp,block,input_file,before_points,output_file,after_points,elapsed_seconds,status,cc_exit_code" > "$LOG_FILE"
fi

count_points() {
  local file="$1"
  python3 - "$file" <<'PY'
import sys, struct
path = sys.argv[1]
try:
    import laspy
    las = laspy.read(path)
    print(len(las.points))
except Exception:
    try:
        with open(path, 'rb') as f:
            header = f.read(375)
        if len(header) < 111:
            raise RuntimeError('file too small')
        major = header[24]
        minor = header[25]
        if major == 1 and minor < 4:
            print(struct.unpack_from('<I', header, 107)[0])
        else:
            # LAS 1.4 extended point count location
            print(struct.unpack_from('<Q', header, 247)[0])
    except Exception:
        print('NA')
PY
}

now_iso() {
  date '+%Y-%m-%d %H:%M:%S'
}

# macOS-friendly epoch time
now_epoch() {
  date +%s
}

# Find the newest cloud file created after the run started.
find_output_file() {
  local block="$1"
  local start_epoch="$2"
  local input_file="$3"
  local newest=""
  local newest_mtime=0
  shopt -s nullglob
  for f in "$INPUT_DIR"/*.laz "$INPUT_DIR"/*.las; do
    [[ -e "$f" ]] || continue
    [[ "$f" == "$input_file" ]] && continue
    base=$(basename "$f")
    # Match files that start with the exact block name, but do not confuse
    # 2026_bloc1 with 2026_bloc10 / 2026_bloc11 / 2026_bloc12.
    if [[ "$base" != "$block"* || "$base" =~ ^${block}[0-9] ]]; then
      continue
    fi
    local mtime
    mtime=$(stat -f %m "$f" 2>/dev/null || echo 0)
    if [[ "$mtime" -ge "$start_epoch" && "$mtime" -ge "$newest_mtime" ]]; then
      newest="$f"
      newest_mtime="$mtime"
    fi
  done
  shopt -u nullglob
  printf '%s' "$newest"
}

for i in $(seq 1 12); do
  block="2026_bloc${i}"
  input_file="$INPUT_DIR/${block}.las"
  timestamp=$(now_iso)

  if [[ ! -f "$input_file" ]]; then
    echo "$timestamp,$block,$input_file,NA,NA,NA,0,missing_input,NA" >> "$LOG_FILE"
    echo "[$timestamp] $block: missing input file" >&2
    continue
  fi

  before_points=$(count_points "$input_file")
  start_epoch=$(now_epoch)
  start_human=$(now_iso)

  run_log="$INPUT_DIR/${block}_cloudcompare_stdout.log"
  : > "$run_log"

  "$CC" -SILENT -AUTO_SAVE OFF -O "$input_file" -CSF -SCENES FLAT -CLASS_THRESHOLD 0.045 -CLOTH_RESOLUTION 0.07 -MAX_ITERATION 500 -SELECT_ENTITIES -REGEX ".*offground.*" -C_EXPORT_FMT LAZ -NOISE RADIUS 0.07 REL 1.0 -SOR 10 1.0 -SAVE_CLOUDS > "$run_log" 2>&1
  cc_exit=$?

  output_file=$(find_output_file "$block" "$start_epoch" "$input_file")
  if [[ -n "$output_file" && -f "$output_file" ]]; then
    after_points=$(count_points "$output_file")
  else
    after_points="NA"
  fi

  end_epoch=$(now_epoch)
  elapsed=$((end_epoch - start_epoch))

  if [[ $cc_exit -eq 0 && -n "$output_file" && -f "$output_file" ]]; then
    status="success"
  else
    status="failure"
  fi

  printf '%s,%s,%s,%s,%s,%s,%s,%s,%s\n' \
    "$start_human" "$block" "$input_file" "$before_points" "$output_file" "$after_points" "$elapsed" "$status" "$cc_exit" \
    >> "$LOG_FILE"

  echo "[$start_human] $block -> $status ($elapsed s, before=$before_points, after=$after_points)"
done

echo "Done. Log written to: $LOG_FILE"
