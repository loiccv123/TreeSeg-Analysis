"""
lidar_tls_scan_cropper_radius.py
Standalone script — run with regular Python.

Requires:
    pip install laspy numpy

For every .las file in INPUT_DIR:
    - crops to a vertical cylinder in XY
    - preserves full LAS precision and metadata
    - writes cropped LAS individually
    - merges all cropped LAS files into one large LAS
"""
import os
import sys
import json
import time
import traceback
import logging

import numpy as np
import laspy

# ── CONFIGURATION ─────────────────────────────────────────────────────────────

INPUT_DIR = r"C:\Users\Labo Messier\Downloads\2026_bloc2"

OUTPUT_DIR = r"C:\Users\Labo Messier\Downloads\2026_bloc2_cropped_files"

CENTER_FILE = r"C:\Users\Labo Messier\Downloads\scanner_centers_8mai.json"

MERGED_OUTPUT_NAME = "2026_bloc2.las"

LOG_FILE_NAME = "crop_merge_log.txt"

RADIUS = 20.0  # metres

# ─────────────────────────────────────────────────────────────────────────────

def setup_logger(log_path: str) -> logging.Logger:

    logger = logging.getLogger("lidar_cropper")

    logger.setLevel(logging.INFO)

    logger.handlers.clear()

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s",
        "%Y-%m-%d %H:%M:%S"
    )

    file_handler = logging.FileHandler(
        log_path,
        encoding="utf-8"
    )

    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler(sys.stdout)

    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger

def crop_to_cylinder(
    las_path: str,
    sx: float,
    sy: float,
    radius: float,
    out_path: str
) -> tuple[int, int]:

    """
    Crop LAS using only XY distance.
    Z is untouched.
    """

    las = laspy.read(las_path)

    n_total = len(las.points)

    if n_total == 0:

        las.write(out_path)

        return 0, 0

    x = np.asarray(las.x, dtype=np.float64)
    y = np.asarray(las.y, dtype=np.float64)

    dist_sq = (x - sx) ** 2 + (y - sy) ** 2

    mask = dist_sq <= radius * radius

    n_kept = int(mask.sum())

    # Preserve exact point structure
    out_las = laspy.LasData(las.header)

    out_las.points = las.points[mask]

    out_las.write(out_path)

    return n_kept, n_total

def merge_las_files(
    las_paths: list[str],
    output_path: str,
    logger: logging.Logger
) -> int:

    """
    Merge multiple LAS files into one LAS.

    All files are decoded to real-world float coordinates using their
    own header offset/scale, then re-encoded relative to the first
    file's offset.  This is safe whether or not all files share the
    same offset, and keeps the output in the same coordinate frame as
    the input project.
    """

    if not las_paths:
        raise RuntimeError("No LAS files to merge.")

    logger.info("")
    logger.info("=" * 60)
    logger.info("MERGING CROPPED LAS FILES")
    logger.info("=" * 60)

    t0 = time.perf_counter()

    # ── Read first file — its offset/scale become the output reference ───
    first_las = laspy.read(las_paths[0])

    ref_scales  = first_las.header.scales   # (sx, sy, sz)
    ref_offsets = first_las.header.offsets  # (ox, oy, oz)

    logger.info(f"Reference offset : {ref_offsets}")
    logger.info(f"Reference scales : {ref_scales}")

    # ── Pass 1: decode every file → real coords → re-encode to ref ───────
    merged_raws = []
    total_points = 0

    for path in las_paths:

        las = laspy.read(path)

        n = len(las.points)

        # Decode using this file's own offset/scale (laspy does this for us)
        x = np.asarray(las.x, dtype=np.float64)
        y = np.asarray(las.y, dtype=np.float64)
        z = np.asarray(las.z, dtype=np.float64)

        # Copy the raw structured array so we can overwrite X/Y/Z integers
        raw = las.points.array.copy()

        # Re-encode relative to the reference (first file) offset/scale
        raw["X"] = np.round((x - ref_offsets[0]) / ref_scales[0]).astype(np.int32)
        raw["Y"] = np.round((y - ref_offsets[1]) / ref_scales[1]).astype(np.int32)
        raw["Z"] = np.round((z - ref_offsets[2]) / ref_scales[2]).astype(np.int32)

        merged_raws.append(raw)
        total_points += n

        logger.info(
            f"Added {n:,} points | "
            f"{os.path.basename(path)}"
        )

    # ── Concatenate all re-encoded raw arrays ─────────────────────────────
    merged_raw_array = np.concatenate(merged_raws)

    # ── Build output LAS with a clean header ──────────────────────────────
    out_header = laspy.LasHeader(
        point_format=first_las.point_format,
        version=first_las.header.version,
    )
    out_header.scales  = ref_scales
    out_header.offsets = ref_offsets

    merged_las = laspy.LasData(out_header)

    merged_las.points = laspy.ScaleAwarePointRecord(
        merged_raw_array,
        point_format=first_las.point_format,
        scales=ref_scales,
        offsets=ref_offsets,
    )

    merged_las.write(output_path)

    elapsed = time.perf_counter() - t0

    logger.info("")
    logger.info(f"Merged LAS written:")
    logger.info(output_path)

    logger.info(
        f"Merged total points: {total_points:,}"
    )

    logger.info(
        f"Merge completed in {elapsed:.2f} sec"
    )

    return total_points

def main() -> None:

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    log_path = os.path.join(
        OUTPUT_DIR,
        LOG_FILE_NAME
    )

    logger = setup_logger(log_path)

    script_start = time.perf_counter()

    logger.info("=" * 60)
    logger.info("LIDAR TLS CYLINDER CROPPER")
    logger.info("=" * 60)

    logger.info(f"Input dir : {INPUT_DIR}")
    logger.info(f"Output dir: {OUTPUT_DIR}")
    logger.info(f"Radius    : {RADIUS:.2f} m")

    # ── Validate center file ────────────────────────────────────────────────

    if not os.path.isfile(CENTER_FILE):

        logger.error(
            f"scanner_centers.json not found:\n{CENTER_FILE}"
        )

        sys.exit(1)

    # ── Load centers ────────────────────────────────────────────────────────

    with open(CENTER_FILE, "r") as f:

        centers = json.load(f)

    logger.info(
        f"Loaded {len(centers)} scanner centers"
    )

    # ── Find LAS files ──────────────────────────────────────────────────────

    las_files = sorted(
        fn for fn in os.listdir(INPUT_DIR)
        if fn.lower().endswith(".las")
    )

    if not las_files:

        logger.error(
            f"No LAS files found in:\n{INPUT_DIR}"
        )

        sys.exit(1)

    logger.info(f"Found {len(las_files)} LAS files")

    # ── Stats ───────────────────────────────────────────────────────────────

    cropped_files = []

    total_input_points = 0
    total_kept_points = 0

    skipped_files = []
    failed_files = []

    # ── Crop each LAS ───────────────────────────────────────────────────────

    for i, fn in enumerate(las_files, start=1):

        stem = os.path.splitext(fn)[0]

        logger.info("")
        logger.info(
            f"[{i}/{len(las_files)}] Processing {fn}"
        )

        if stem not in centers:

            logger.warning(
                f"Skipping {fn} (no center found)"
            )

            skipped_files.append(fn)

            continue

        pos = centers[stem]

        sx = pos["x"]
        sy = pos["y"]

        in_path = os.path.join(INPUT_DIR, fn)

        out_path = os.path.join(OUTPUT_DIR, fn)

        try:

            t0 = time.perf_counter()

            kept, total = crop_to_cylinder(
                in_path,
                sx,
                sy,
                RADIUS,
                out_path
            )

            elapsed = time.perf_counter() - t0

            pct = (
                kept / total * 100.0
                if total > 0 else 0.0
            )

            logger.info(
                f"Kept {kept:,} / {total:,} points "
                f"({pct:.2f}%) | "
                f"{elapsed:.2f} sec"
            )

            total_input_points += total
            total_kept_points += kept

            cropped_files.append(out_path)

        except Exception as e:

            failed_files.append(fn)

            logger.error(
                f"ERROR processing {fn}"
            )

            logger.error(str(e))

            logger.error(
                traceback.format_exc()
            )

    # ── Merge LAS files ─────────────────────────────────────────────────────

    merged_output_path = os.path.join(
        OUTPUT_DIR,
        MERGED_OUTPUT_NAME
    )

    merged_points = merge_las_files(
        cropped_files,
        merged_output_path,
        logger
    )

    # ── Final verification ──────────────────────────────────────────────────

    total_elapsed = time.perf_counter() - script_start

    logger.info("")
    logger.info("=" * 60)
    logger.info("FINAL SUMMARY")
    logger.info("=" * 60)

    logger.info(
        f"Input points : {total_input_points:,}"
    )

    logger.info(
        f"Cropped pts  : {total_kept_points:,}"
    )

    logger.info(
        f"Merged pts   : {merged_points:,}"
    )

    if merged_points == total_kept_points:

        logger.info(
            "Point verification PASSED"
        )

    else:

        logger.warning(
            "Point count mismatch detected"
        )

    logger.info(
        f"Skipped files: {len(skipped_files)}"
    )

    logger.info(
        f"Failed files : {len(failed_files)}"
    )

    logger.info(
        f"Total runtime: {total_elapsed:.2f} sec"
    )

    logger.info("=" * 60)
    logger.info("ALL DONE")
    logger.info("=" * 60)


if __name__ == "__main__":
    main()