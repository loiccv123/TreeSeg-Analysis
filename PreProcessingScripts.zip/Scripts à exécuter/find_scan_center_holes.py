import os
import json
import numpy as np
import laspy
from scipy import ndimage

# ── Configuration ────────────────────────────────────────────────────────────
INPUT_DIR   = r"C:\Users\Labo Messier\Downloads\8_mai_individual_aligned_scans"
OUTPUT_JSON = r"C:\Users\Labo Messier\Downloads\scanner_centers_8mai.json"

# Coarse grid for fast hole search
CELL        = 0.05      # 5 cm grid cells
LOCAL_HALF  = 2.50      # crop to a 5 m x 5 m window around scan center
SEARCH_HALF = 0.45      # only search near the middle of the cropped window

# Expected hole size from your image
HOLE_RADIUS = 0.67      # ~1.33 m diameter / 2
RIM_TOL     = 0.10      # points used for final circle fit
# ─────────────────────────────────────────────────────────────────────────────


def least_squares_circle(xy: np.ndarray):
    """Algebraic least-squares circle fit. Returns (cx, cy, radius)."""
    x, y = xy[:, 0], xy[:, 1]
    A = np.column_stack([2 * x, 2 * y, np.ones(len(x))])
    b = x**2 + y**2
    result, _, _, _ = np.linalg.lstsq(A, b, rcond=None)
    cx, cy, c = result
    radius = np.sqrt(c + cx**2 + cy**2)
    return cx, cy, radius


def find_hole_xy(las_path: str):
    """Return (cx, cy) of the scanner hole, or None if not found."""
    las = laspy.read(las_path)
    x = np.asarray(las.x, dtype=np.float64)
    y = np.asarray(las.y, dtype=np.float64)

    if x.size < 1000:
        return None

    # Very cheap initial guess: center of the point cloud in XY
    cx0 = np.median(x)
    cy0 = np.median(y)

    # Crop to a local window around the center to keep everything fast
    keep = (
        (np.abs(x - cx0) <= LOCAL_HALF) &
        (np.abs(y - cy0) <= LOCAL_HALF)
    )
    x = x[keep]
    y = y[keep]

    if x.size < 500:
        return None

    x_min, x_max = cx0 - LOCAL_HALF, cx0 + LOCAL_HALF
    y_min, y_max = cy0 - LOCAL_HALF, cy0 + LOCAL_HALF

    nx = int(np.ceil((x_max - x_min) / CELL)) + 1
    ny = int(np.ceil((y_max - y_min) / CELL)) + 1

    # 2D occupancy grid: True where at least one point exists
    hist, _, _ = np.histogram2d(
        y, x,
        bins=[ny, nx],
        range=[[y_min, y_max], [x_min, x_max]]
    )
    occ = hist > 0

    # Build a circular kernel roughly matching the hole size
    rr = int(np.ceil(HOLE_RADIUS / CELL))
    yy, xx = np.ogrid[-rr:rr+1, -rr:rr+1]
    disk = ((xx * xx + yy * yy) <= rr * rr).astype(np.uint8)

    # Convolve occupancy with disk kernel:
    # low values = empty disk = likely hole center
    score = ndimage.convolve(
        occ.astype(np.uint8),
        disk,
        mode="constant",
        cval=1
    )

    # Search only near the center of the cropped window
    r_center = ny // 2
    c_center = nx // 2
    s = int(np.ceil(SEARCH_HALF / CELL))

    r0 = max(0, r_center - s)
    r1 = min(ny, r_center + s + 1)
    c0 = max(0, c_center - s)
    c1 = min(nx, c_center + s + 1)

    sub = score[r0:r1, c0:c1]
    best_r, best_c = np.unravel_index(np.argmin(sub), sub.shape)
    best_r += r0
    best_c += c0

    # Convert best grid cell center back to world coordinates
    cx1 = x_min + (best_c + 0.5) * CELL
    cy1 = y_min + (best_r + 0.5) * CELL

    # Final refinement: fit circle to points near the estimated rim
    d = np.hypot(x - cx1, y - cy1)

    # Estimate rim radius from radial histogram around the candidate
    valid = (d > 0.20) & (d < 1.20)
    if valid.sum() < 50:
        return float(cx1), float(cy1)

    bins = np.arange(0.20, 1.20 + 0.02, 0.02)
    h, edges = np.histogram(d[valid], bins=bins)
    i = int(np.argmax(h))
    r_est = 0.5 * (edges[i] + edges[i + 1])

    rim = np.abs(d - r_est) < RIM_TOL
    if rim.sum() < 20:
        return float(cx1), float(cy1)

    cx2, cy2, _ = least_squares_circle(np.column_stack([x[rim], y[rim]]))
    return float(cx2), float(cy2)


def main():
    las_files = [
        f for f in os.listdir(INPUT_DIR)
        if f.lower().endswith((".las", ".laz"))
    ]

    if not las_files:
        print(f"No .las/.laz files found in {INPUT_DIR}")
        return

    output = {}

    for fname in sorted(las_files):
        path = os.path.join(INPUT_DIR, fname)
        label = os.path.splitext(fname)[0]
        print(f"Processing: {fname}")

        result = find_hole_xy(path)
        if result is None:
            print("  → hole not found, skipping")
            continue

        cx, cy = result
        output[label] = {
            "x": cx,
            "y": cy,
            "source_label": label,
        }
        print(f"  → center x={cx:.4f}  y={cy:.4f}")

    with open(OUTPUT_JSON, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\nSaved {len(output)} entries → {OUTPUT_JSON}")


if __name__ == "__main__":
    main()